import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

const paper = Color(0xfff0f8ff);
const cover = Color(0xff89c9ed);
const ink = Color(0xff416b90);
const trim = Color(0xffb7d8f0);
const accent = Color(0xffd5ebfc);

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const RosterApp()); }

class Student {
  String id, name, school, club, comment;
  int age, grade, month, day;
  List<String> photos;
  Student({required this.id, required this.name, required this.age, required this.month, required this.day, required this.school, required this.grade, required this.club, required this.comment, required this.photos});
  String get givenName => name.trim().split(RegExp(r'\s+')).last;
  Map<String,dynamic> toJson() => {'id':id,'name':name,'age':age,'month':month,'day':day,'school':school,'grade':grade,'club':club,'comment':comment,'photos':photos};
  factory Student.fromJson(Map<String,dynamic> j) => Student(id:'${j['id']}',name:'${j['name']}',age:(j['age'] as num).toInt(),month:(j['month'] as num).toInt(),day:(j['day'] as num).toInt(),school:'${j['school']}',grade:(j['grade'] as num).toInt(),club:'${j['club']}',comment:'${j['comment']??''}',photos:List<String>.from(j['photos']??[]));
  Student clone() => Student.fromJson(toJson());
}

class Store extends ChangeNotifier {
  List<Student> students=[];
  late Directory home;
  Future<void> init() async {
    home=await getApplicationDocumentsDirectory();
    final f=File(p.join(home.path,'students.json'));
    if(await f.exists()) {
      try {students=(jsonDecode(await f.readAsString()) as List).map((e)=>Student.fromJson(Map<String,dynamic>.from(e))).toList();} catch (_) {students=[];}
    }
    notifyListeners();
  }
  Future<void> persist() async {
    final file=File(p.join(home.path,'students.json'));
    await file.writeAsString(jsonEncode(students.map((e)=>e.toJson()).toList()),flush:true);
    notifyListeners();
  }
  Future<String> ownPhoto(String source) async {
    final folder=Directory(p.join(home.path,'photos')); await folder.create(recursive:true);
    final ext=p.extension(source).toLowerCase();
    final target=p.join(folder.path,'${DateTime.now().microsecondsSinceEpoch}_${math.Random().nextInt(100000)}${ext.isEmpty?'.jpg':ext}');
    await File(source).copy(target);
    return target;
  }
  Future<void> saveStudent(Student s) async {
    final photos=<String>[];
    for(final photo in s.photos) {
      if(photo.startsWith(home.path)) {photos.add(photo);} else {photos.add(await ownPhoto(photo));}
    }
    s.photos=photos;
    final idx=students.indexWhere((e)=>e.id==s.id);
    if(idx<0) {students.add(s);} else {students[idx]=s;}
    await persist();
  }
  Future<void> deleteStudent(String id) async {
    students.removeWhere((e)=>e.id==id); await persist();
  }
  Future<File> backup() async {
    final archive=Archive();
    final manifest=utf8.encode(jsonEncode(students.map((e)=>e.toJson()).toList().map((e){
      final data=Map<String,dynamic>.from(e);
      data['photos']=(data['photos'] as List).map((x)=>'photos/${p.basename('$x')}').toList();
      return data;
    }).toList()));
    archive.addFile(ArchiveFile('students.json',manifest.length,manifest));
    final seen=<String>{};
    for(final s in students) {for(final path in s.photos) {
      final file=File(path); final name='photos/${p.basename(path)}';
      if(!seen.add(name)||!await file.exists()) continue;
      final bytes=await file.readAsBytes(); archive.addFile(ArchiveFile(name,bytes.length,bytes));
    }}
    final zip=ZipEncoder().encode(archive)!;
    final tmp=await getTemporaryDirectory();
    final out=File(p.join(tmp.path,'kivotos_backup_${DateTime.now().millisecondsSinceEpoch}.zip'));
    await out.writeAsBytes(zip,flush:true); return out;
  }
  Future<void> restore(String filePath) async {
    final bytes=await File(filePath).readAsBytes();
    final arc=ZipDecoder().decodeBytes(bytes);
    final manifest=arc.files.where((e)=>e.name=='students.json').first;
    final jsonText=utf8.decode(manifest.content as List<int>);
    final raw=jsonDecode(jsonText) as List;
    final newStudents=raw.map((e)=>Student.fromJson(Map<String,dynamic>.from(e))).toList();
    final folder=Directory(p.join(home.path,'photos')); await folder.create(recursive:true);
    final extracted=<String,String>{};
    for(final entry in arc.files) {
      if(!entry.isFile || !entry.name.startsWith('photos/')) continue;
      final name=p.basename(entry.name);
      if(name.isEmpty) continue;
      final safe='${DateTime.now().microsecondsSinceEpoch}_${math.Random().nextInt(100000)}_$name';
      final dest=p.join(folder.path,safe);
      await File(dest).writeAsBytes(entry.content as List<int>);
      extracted[entry.name]=dest;
    }
    for(final s in newStudents) {s.photos=s.photos.map((x)=>extracted[x]).whereType<String>().toList();}
    students=newStudents; await persist();
  }
}

class RosterApp extends StatefulWidget {const RosterApp({super.key}); @override State<RosterApp> createState()=>_RosterAppState();}
class _RosterAppState extends State<RosterApp> {
  final store=Store(); bool ready=false;
  @override void initState(){super.initState(); store.init().then((_){if(mounted)setState(()=>ready=true);});}
  @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'키보토스 학생명부',theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:cover),fontFamily:null,scaffoldBackgroundColor:const Color(0xffdcebf7)),home:!ready?const Scaffold(body:Center(child:CircularProgressIndicator())):Notebook(store:store));
}

enum Screen {cover, toc, view, edit}
enum SortMode {name, school, grade, age, birthday}

class Notebook extends StatefulWidget {final Store store; const Notebook({super.key,required this.store}); @override State<Notebook> createState()=>_NotebookState();}
class _NotebookState extends State<Notebook> {
  Screen screen=Screen.cover; Student? active; SortMode sort=SortMode.name;
  String query=''; int page=0; bool turning=false; int direction=1;
  Future<void> go(Screen next,{Student? student,int? pageIndex,int dir=1}) async {
    if(turning)return;
    setState((){turning=true;direction=dir;});
    await Future.delayed(Duration(milliseconds:(screen==Screen.cover?620:next==Screen.view||screen==Screen.view?950:420)));
    if(!mounted)return;
    setState((){screen=next; if(student!=null)active=student; if(pageIndex!=null)page=pageIndex; turning=false;});
  }
  String initial(String input){
    if(input.isEmpty)return '#';
    final n=input.runes.first;
    if(n>=0xac00&&n<=0xd7a3){const initials=['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];return initials[(n-0xac00)~/588];}
    return input[0].toUpperCase();
  }
  String group(Student s){switch(sort){case SortMode.name:return initial(s.givenName);case SortMode.school:return s.school;case SortMode.grade:return '${s.grade}학년';case SortMode.age:return '${s.age}세';case SortMode.birthday:return '${s.month}월';}}
  List<Student> get ordered {
    final items=widget.store.students.where((s)=>s.givenName.toLowerCase().contains(query.trim().toLowerCase())||s.name.toLowerCase().contains(query.trim().toLowerCase())).toList();
    int cmp(Student a,Student b){int c=0;switch(sort){case SortMode.name:c=a.givenName.compareTo(b.givenName);break;case SortMode.school:c=a.school.compareTo(b.school);break;case SortMode.grade:c=a.grade.compareTo(b.grade);break;case SortMode.age:c=a.age.compareTo(b.age);break;case SortMode.birthday:c=a.month.compareTo(b.month);if(c==0)c=a.day.compareTo(b.day);break;}return c!=0?c:a.givenName.compareTo(b.givenName);}
    items.sort(cmp);return items;
  }
  Future<bool> confirm(String message) async => await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('확인'),content:Text(message),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('아니요')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('예'))]))??false;
  Future<void> notice(String message) async {await showDialog<void>(context:context,builder:(c)=>AlertDialog(content:Text(message),actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('확인'))]));}
  Future<void> newStudent() async {if(!await confirm('학생을 추가하시겠습니까?'))return;if(!mounted)return;await editStudent(null);}
  Future<void> editStudent(Student? original) async {
    final result=await Navigator.of(context).push<bool>(MaterialPageRoute(builder:(c)=>Editor(store:widget.store,original:original)));
    if(!mounted)return;
    if(result==true){setState(()=>active=null);await go(Screen.toc,dir:-1);} else if(original!=null){setState(()=>active=widget.store.students.where((s)=>s.id==original.id).firstOrNull);}
  }
  Future<void> exportData() async {try{final file=await widget.store.backup();await Share.shareXFiles([XFile(file.path)],text:'키보토스 학생명부 백업');}catch(e){if(mounted)await notice('백업에 실패했습니다: $e');}}
  Future<void> importData() async {
    if(!await confirm('백업을 복원하면 현재 학생명부가 모두 교체됩니다. 계속하시겠습니까?'))return;
    try{final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['zip']);if(result==null||result.files.single.path==null)return;await widget.store.restore(result.files.single.path!);if(mounted){setState(()=>page=0);await notice('복원이 완료되었습니다');}}catch(e){if(mounted)await notice('복원에 실패했습니다: $e');}
  }
  @override Widget build(BuildContext context){
    final list=ordered;final total=math.max(1,(list.length/8).ceil());final actualPage=math.min(page,total-1);
    final slice=list.skip(actualPage*8).take(8).toList();
    return Scaffold(body:SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:620),child:Stack(children:[
      if(screen==Screen.cover) _cover(),
      if(screen==Screen.toc) _sheet(Column(children:[_heading('목차'),const SizedBox(height:10),Row(children:[Expanded(child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'학생 이름 검색',isDense:true,border:OutlineInputBorder()),onChanged:(v)=>setState((){query=v;page=0;}))),const SizedBox(width:8),DropdownButton<SortMode>(value:sort,items:const [DropdownMenuItem(value:SortMode.name,child:Text('이름')),DropdownMenuItem(value:SortMode.school,child:Text('학교')),DropdownMenuItem(value:SortMode.grade,child:Text('학년')),DropdownMenuItem(value:SortMode.age,child:Text('나이')),DropdownMenuItem(value:SortMode.birthday,child:Text('생일'))],onChanged:(v)=>setState((){sort=v??sort;page=0;}))]),const SizedBox(height:14),Expanded(child:list.isEmpty?Center(child:Text(query.isEmpty?'등록된 학생이 없습니다.\n오른쪽의 포스트잇을 눌러 추가해 주세요.':'검색 결과가 없습니다.',textAlign:TextAlign.center,style:const TextStyle(color:ink))):ListView(children:[for(var i=0;i<slice.length;i++)...[
        if(i==0||group(slice[i])!=group(slice[i-1])) Padding(padding:const EdgeInsets.only(top:12,bottom:3),child:Text(group(slice[i]),style:const TextStyle(color:Color(0xff397dae),fontSize:17,fontWeight:FontWeight.bold))),
        ListTile(dense:true,contentPadding:const EdgeInsets.only(left:16,right:4),title:Text(slice[i].givenName,style:const TextStyle(color:ink,fontSize:16)),trailing:const Icon(Icons.chevron_right,color:ink),onTap:()=>go(Screen.view,student:slice[i])),const Divider(height:1,color:trim)
      ]])),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[IconButton(onPressed:actualPage>0?()=>go(Screen.toc,pageIndex:actualPage-1,dir:-1):null,icon:const Icon(Icons.chevron_left)),TextButton(onPressed:()=>showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(shrinkWrap:true,children:[for(int i=0;i<total;i++)ListTile(title:Text('${i+1} 페이지'),onTap:(){Navigator.pop(c);go(Screen.toc,pageIndex:i,dir:i>=actualPage?1:-1);})]))),child:Text('${actualPage+1} / $total ▾')),IconButton(onPressed:actualPage<total-1?()=>go(Screen.toc,pageIndex:actualPage+1):null,icon:const Icon(Icons.chevron_right))])]),tabs:[TabSpec('새 학생 추가',const Color(0xffffe8a9),newStudent),TabSpec('백업',const Color(0xffc4f1db),exportData),TabSpec('복원',const Color(0xffffcbd5),importData)]),
      if(screen==Screen.view&&active!=null) _sheet(StudentDisplay(student:active!,onPhoto:()=>showDialog(context:context,builder:(c)=>PhotoViewer(paths:active!.photos))),tabs:[TabSpec('돌아가기',const Color(0xffffe8a9),()=>go(Screen.toc,dir:-1)),TabSpec('수정',const Color(0xffc4f1db),()=>editStudent(active))]),
      if(turning) Positioned.fill(child:IgnorePointer(child:AnimatedSheetTurn(key:ValueKey('${screen.name}-${direction}'),reverse:direction<0))),
    ]))));
  }
  Widget _heading(String text)=>Padding(padding:const EdgeInsets.symmetric(vertical:9),child:Text(text,style:const TextStyle(fontSize:26,color:ink,fontWeight:FontWeight.w800)));
  Widget _cover()=>GestureDetector(onTap:()=>go(Screen.toc),child:Container(margin:const EdgeInsets.fromLTRB(22,22,12,22),decoration:BoxDecoration(color:cover,borderRadius:BorderRadius.circular(16),boxShadow:const [BoxShadow(color:Colors.black26,blurRadius:14,offset:Offset(3,7))]),child:Stack(children:[Positioned(left:10,top:0,bottom:0,child:Column(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:List.generate(12,(_)=>Container(width:23,height:9,decoration:BoxDecoration(color:const Color(0xffdae2e9),borderRadius:BorderRadius.circular(9),border:Border.all(color:const Color(0xff8d9da8)))))),Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.menu_book_rounded,color:Colors.white,size:56),const SizedBox(height:20),const Text('키보토스\n학생 명부',textAlign:TextAlign.center,style:TextStyle(fontSize:36,color:Colors.white,fontWeight:FontWeight.w800,height:1.45)),const SizedBox(height:42),Text('터치하여 펼치기',style:TextStyle(color:Colors.white.withOpacity(.85)))]))])));
  Widget _sheet(Widget content,{required List<TabSpec> tabs})=>Container(margin:const EdgeInsets.fromLTRB(12,12,10,12),decoration:BoxDecoration(color:paper,borderRadius:BorderRadius.circular(9),border:Border.all(color:trim),boxShadow:const [BoxShadow(color:Colors.black12,blurRadius:10,offset:Offset(2,5))]),child:Stack(children:[Padding(padding:const EdgeInsets.fromLTRB(20,15,18,15),child:content),Positioned(right:0,top:75,child:Column(children:[for(final t in tabs)Padding(padding:const EdgeInsets.only(bottom:7),child:InkWell(onTap:t.onTap,child:Container(width:30,height:80,alignment:Alignment.center,decoration:BoxDecoration(color:t.color,borderRadius:const BorderRadius.horizontal(left:Radius.circular(7))),child:RotatedBox(quarterTurns:1,child:Text(t.title,style:const TextStyle(color:ink,fontWeight:FontWeight.bold,fontSize:12)))))]))]));
}
class TabSpec {final String title;final Color color;final VoidCallback onTap;TabSpec(this.title,this.color,this.onTap);}

class AnimatedSheetTurn extends StatefulWidget {final bool reverse;const AnimatedSheetTurn({super.key,required this.reverse});@override State<AnimatedSheetTurn> createState()=>_AnimatedSheetTurnState();}
class _AnimatedSheetTurnState extends State<AnimatedSheetTurn> with SingleTickerProviderStateMixin {
  late AnimationController controller;
  @override void initState(){super.initState();controller=AnimationController(vsync:this,duration:const Duration(milliseconds:880))..forward();}
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:controller,builder:(c,child)=>Stack(children:[for(int i=0;i<5;i++)Builder(builder:(c){final t=((controller.value-i*.11)/.5).clamp(0.0,1.0);final scale=(1-t).clamp(0.0,1.0);return Positioned.fill(child:Align(alignment:widget.reverse?Alignment.centerLeft:Alignment.centerRight,child:FractionallySizedBox(widthFactor:scale,child:Container(margin:const EdgeInsets.all(14),decoration:BoxDecoration(color:i.isEven?paper:const Color(0xffdcebf7),borderRadius:BorderRadius.circular(8),border:Border.all(color:trim),boxShadow:const [BoxShadow(color:Colors.black12,blurRadius:7)])))));})]));
}

class StudentDisplay extends StatelessWidget {final Student student;final VoidCallback onPhoto;const StudentDisplay({super.key,required this.student,required this.onPhoto});
  @override Widget build(BuildContext context)=>ListView(children:[const SizedBox(height:8),const Text('학생 개인 기록부',textAlign:TextAlign.center,style:TextStyle(color:ink,fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:20),Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(flex:4,child:GestureDetector(onTap:student.photos.isEmpty?null:onPhoto,child:AspectRatio(aspectRatio:3/4,child:Container(decoration:BoxDecoration(color:accent,border:Border.all(color:trim),borderRadius:BorderRadius.circular(10)),clipBehavior:Clip.antiAlias,child:student.photos.isEmpty?const Icon(Icons.person,color:ink,size:55):Image.file(File(student.photos.first),fit:BoxFit.cover,errorBuilder:(c,e,s)=>const Icon(Icons.broken_image)))))),const SizedBox(width:12),Expanded(flex:6,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[_field('이름',student.name),_field('나이','${student.age}세'),_field('생일','${student.month}월 ${student.day}일'),_field('소속 학교',student.school),_field('학년','${student.grade}학년'),_field('소속 동아리',student.club)]))]),const SizedBox(height:22),const Text('코멘트',style:TextStyle(color:ink,fontSize:18,fontWeight:FontWeight.bold)),const Divider(color:trim),Container(constraints:const BoxConstraints(minHeight:160),padding:const EdgeInsets.all(12),child:Text(student.comment.isEmpty?'작성된 코멘트가 없습니다.':student.comment,style:const TextStyle(color:ink,fontSize:15,height:1.6)))]);
  Widget _field(String label,String value)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(color:Color(0xff6b9bbd),fontSize:11,fontWeight:FontWeight.bold)),Text(value,style:const TextStyle(color:ink,fontSize:14,fontWeight:FontWeight.w600))]));
}

class PhotoViewer extends StatefulWidget {final List<String> paths;const PhotoViewer({super.key,required this.paths});@override State<PhotoViewer> createState()=>_PhotoViewerState();}
class _PhotoViewerState extends State<PhotoViewer> {int index=0;@override Widget build(BuildContext context)=>Dialog(backgroundColor:const Color(0xff152c40),insetPadding:const EdgeInsets.all(12),child:Stack(children:[Padding(padding:const EdgeInsets.symmetric(horizontal:35,vertical:50),child:Image.file(File(widget.paths[index]),fit:BoxFit.contain,errorBuilder:(c,e,s)=>const Icon(Icons.broken_image,color:Colors.white))),Positioned(top:3,right:3,child:IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close,color:Colors.white))),Positioned(left:0,top:0,bottom:0,child:Center(child:CircleAvatar(backgroundColor:Colors.white38,child:IconButton(onPressed:()=>setState(()=>index=(index-1+widget.paths.length)%widget.paths.length),icon:const Icon(Icons.chevron_left,color:Colors.white))))),Positioned(right:0,top:0,bottom:0,child:Center(child:CircleAvatar(backgroundColor:Colors.white38,child:IconButton(onPressed:()=>setState(()=>index=(index+1)%widget.paths.length),icon:const Icon(Icons.chevron_right,color:Colors.white))))),Positioned(bottom:10,left:0,right:0,child:Text('${index+1} / ${widget.paths.length}',textAlign:TextAlign.center,style:const TextStyle(color:Colors.white)))]));}
}

class Editor extends StatefulWidget {final Store store;final Student? original;const Editor({super.key,required this.store,this.original});@override State<Editor> createState()=>_EditorState();}
class _EditorState extends State<Editor> {
  final name=TextEditingController(),age=TextEditingController(),school=TextEditingController(),grade=TextEditingController(),club=TextEditingController(),comment=TextEditingController();
  int? month,day; List<String> photos=[];bool busy=false;
  @override void initState(){super.initState();final s=widget.original;if(s!=null){name.text=s.name;age.text='${s.age}';school.text=s.school;grade.text='${s.grade}';club.text=s.club;comment.text=s.comment;month=s.month;day=s.day;photos=List.from(s.photos);}}
  @override void dispose(){for(final x in [name,age,school,grade,club,comment]){x.dispose();}super.dispose();}
  int get maxDay=>month==null?31:DateTime(2024,month!+1,0).day;
  Future<bool> ask(String msg)async=>await showDialog<bool>(context:context,builder:(c)=>AlertDialog(content:Text(msg),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('아니요')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('예'))]))??false;
  Future<void> info(String msg,{String button='확인'})async=>showDialog<void>(context:context,builder:(c)=>AlertDialog(content:Text(msg),actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:Text(button))]));
  Future<void> save()async{
    if(!await ask('저장하시겠습니까?'))return;
    final a=int.tryParse(age.text.trim()),g=int.tryParse(grade.text.trim());
    if(name.text.trim().isEmpty||a==null||a<=0||g==null||g<=0||month==null||day==null||school.text.trim().isEmpty||club.text.trim().isEmpty||photos.isEmpty){await info('필수 항목을 모두 입력해 주세요.',button:'예');return;}
    if(widget.original==null&&widget.store.students.any((s)=>s.name.trim()==name.text.trim())){await info('이미 등록된 학생입니다.');return;}
    setState(()=>busy=true);
    try{
      final s=Student(id:widget.original?.id??'${DateTime.now().microsecondsSinceEpoch}',name:name.text.trim(),age:a,month:month!,day:day!,school:school.text.trim(),grade:g,club:club.text.trim(),comment:comment.text,photos:List.from(photos));
      await widget.store.saveStudent(s);if(!mounted)return;await info('저장되었습니다');if(mounted)Navigator.pop(context,true);
    }catch(e){if(mounted)await info('저장 중 오류가 발생했습니다: $e');}finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> back()async{if(await ask('지금까지 작성하던 학생명부를 저장하지 않고 돌아가시겠습니까?')&&mounted)Navigator.pop(context,false);}
  Future<void> delete()async{if(!await ask('이 개인 기록부를 삭제하시겠습니까?'))return;await widget.store.deleteStudent(widget.original!.id);if(!mounted)return;await info('삭제가 완료되었습니다');if(mounted)Navigator.pop(context,true);}
  Future<void> managePhotos()async{final result=await Navigator.push<List<String>>(context,MaterialPageRoute(builder:(c)=>PhotoManager(initial:photos)));if(result!=null&&mounted)setState(()=>photos=result);}
  Widget input(String label,TextEditingController controller,{TextInputType? type,int lines=1})=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:controller,keyboardType:type,maxLines:lines,decoration:InputDecoration(labelText:label,filled:true,fillColor:Colors.white70,isDense:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(10)))));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.original==null?'새 학생 추가':'학생 기록부 수정'),backgroundColor:accent),body:SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:620),child:Container(margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:paper,borderRadius:BorderRadius.circular(12),border:Border.all(color:trim)),child:ListView(children:[const Text('학생 개인 기록부',textAlign:TextAlign.center,style:TextStyle(color:ink,fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:18),Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(flex:4,child:InkWell(onTap:managePhotos,child:AspectRatio(aspectRatio:3/4,child:Container(decoration:BoxDecoration(color:accent,borderRadius:BorderRadius.circular(10),border:Border.all(color:trim)),clipBehavior:Clip.antiAlias,child:photos.isEmpty?const Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.add_a_photo,color:ink),Text('사진 추가',style:TextStyle(color:ink))]):Image.file(File(photos.first),fit:BoxFit.cover,errorBuilder:(c,e,s)=>const Icon(Icons.broken_image)))))),const SizedBox(width:12),Expanded(flex:6,child:Column(children:[input('이름 *',name),input('나이 *',age,type:TextInputType.number),Row(children:[Expanded(child:DropdownButtonFormField<int>(value:month,decoration:const InputDecoration(labelText:'월 *',isDense:true),items:[for(int i=1;i<=12;i++)DropdownMenuItem(value:i,child:Text('$i'))],onChanged:(v)=>setState((){month=v;if(day!=null&&day!>maxDay)day=null;}))),const SizedBox(width:6),Expanded(child:DropdownButtonFormField<int>(value:day,decoration:const InputDecoration(labelText:'일 *',isDense:true),items:[for(int i=1;i<=maxDay;i++)DropdownMenuItem(value:i,child:Text('$i'))],onChanged:(v)=>setState(()=>day=v)))]),const SizedBox(height:10),input('소속 학교 *',school),input('학년 *',grade,type:TextInputType.number),input('소속 동아리 *',club)]))]),const SizedBox(height:14),Text('사진 ${photos.length} / 6  ·  사진을 누르면 관리 창이 열립니다.',style:const TextStyle(color:ink,fontSize:12)),const SizedBox(height:14),input('코멘트 (선택)',comment,lines:7),const SizedBox(height:14),if(busy)const Center(child:CircularProgressIndicator())else Wrap(spacing:8,runSpacing:8,children:[FilledButton(onPressed:save,child:const Text('저장')),OutlinedButton(onPressed:back,child:const Text('돌아가기')),if(widget.original!=null)OutlinedButton(onPressed:delete,style:OutlinedButton.styleFrom(foregroundColor:Colors.red),child:const Text('삭제'))])]))))));
}

class PhotoManager extends StatefulWidget {final List<String> initial;const PhotoManager({super.key,required this.initial});@override State<PhotoManager> createState()=>_PhotoManagerState();}
class _PhotoManagerState extends State<PhotoManager> {late List<String?> slots;
  @override void initState(){super.initState();slots=List.generate(6,(i)=>i<widget.initial.length?widget.initial[i]:null);}
  Future<bool> ask(String msg)async=>await showDialog<bool>(context:context,builder:(c)=>AlertDialog(content:Text(msg),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('아니요')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('예'))]))??false;
  Future<void> pick(int i)async{try{final x=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:90);if(x!=null&&mounted)setState(()=>slots[i]=x.path);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('사진 선택 실패: $e')));}}
  Future<void> remove(int i)async{if(await ask('사진을 삭제하시겠습니까?')&&mounted)setState(()=>slots[i]=null);}
  Future<void> save()async{if(!await ask('저장하시겠습니까?'))return;if(mounted)Navigator.pop(context,slots.whereType<String>().toList());}
  Future<void> back()async{if(await ask('사진 변경을 저장하지 않고 돌아가시겠습니까?')&&mounted)Navigator.pop(context);}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('사진 관리'),backgroundColor:accent),body:SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:620),child:Container(margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:paper,borderRadius:BorderRadius.circular(12)),child:Column(children:[const Text('사진은 최대 6장까지 등록할 수 있어요.',style:TextStyle(color:ink)),const SizedBox(height:18),Expanded(child:GridView.builder(gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:8,mainAxisSpacing:8,childAspectRatio:.72),itemCount:6,itemBuilder:(c,i)=>InkWell(onTap:slots[i]==null?()=>pick(i):()=>pick(i),child:Stack(children:[Positioned.fill(child:Container(decoration:BoxDecoration(color:accent,border:Border.all(color:trim),borderRadius:BorderRadius.circular(8)),clipBehavior:Clip.antiAlias,child:slots[i]==null?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.add_photo_alternate,color:ink),Text('${i+1}',style:const TextStyle(color:ink))])):Image.file(File(slots[i]!),fit:BoxFit.cover,errorBuilder:(c,e,s)=>const Icon(Icons.broken_image)))),if(slots[i]!=null)Positioned(right:2,top:2,child:CircleAvatar(radius:15,backgroundColor:Colors.white,child:IconButton(padding:EdgeInsets.zero,iconSize:18,onPressed:()=>remove(i),icon:const Icon(Icons.close,color:Colors.red))))]))),const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.end,children:[FilledButton(onPressed:save,child:const Text('저장')),const SizedBox(width:8),OutlinedButton(onPressed:back,child:const Text('돌아가기'))])]))))));
}
